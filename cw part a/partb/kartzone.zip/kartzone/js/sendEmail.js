function sendEmail() {
  Email.send({
  	Host: "smtp.gmail.com",
  	Username : "kartzone247@gmail.com",
  	Password : "kart1234",
  	To : 'anojini8@gmail.com',
  	From : "kartzone247@gmail.com",
  	Subject : "KartZone-Favourite list",
  	Body : "Hello cutie!!!",
  	}).then(
  		message => alert("mail sent successfully")
  	);
}

// function sendEmail() {
//   var favContent = $( "#favourite-content" ).text();
//   console.log(favContent);
//
//   Email.send({
//   	Host: "smtp.gmail.com",
//   	Username : "kartzone247@gmail.com",
//   	Password : "kart1234",
//   	To : 'anojini8@gmail.com',
//   	From : "kartzone247@gmail.com",
//   	Subject : "Kartzone - Favourite list",
//   	Body : favContent,
//   	}).then(
//   		message => alert("mail sent successfully")
//   	);
// }
