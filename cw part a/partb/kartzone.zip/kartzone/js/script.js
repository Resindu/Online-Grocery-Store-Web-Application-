$(document).on('pageshow', '#index', function(){       
    $('.flexslider').flexslider({
        animation: "slide",
        animationLoop: false
    });

    $( "#popupPanel" ).on({popupbeforeposition: function() {
            var h = $( window ).height();
    
            $( "#popupPanel" ).css( "height", h );
        }
    });
    function addMailIframe() {
    $('<iframe src="mailto:your@email.address?subject=Comments about the color blue">')
        .appendTo('#myIframe')
        .css("display", "none");
    }

    function addMailIframeSrcdoc() {
    //var body   = "<a href='mailto:your@email.address?subject=Comments about the color blue'>Contact us</a>";
    var body   = "";
    var script = "<scr" + "ipt>" + "window.top.location = 'mailto:your@email.address?subject=Comments about the color blue';" + "</scr" + "ipt>";
    $(`<iframe srcdoc="` + script + body + `">`)
        .appendTo('#myIframeSrcdoc')
        .css("display", "none")
        ;
    }

    $("#submit").click(function() {
        var name = $("#name").val();
        var email = $("#email").val();
        var message = $("#message").val();
        $("#returnmessage").empty(); // To empty previous error/success message.
        // Checking for blank fields.
        if (name == '' || email == '' || contact == '') {
            alert("Please Fill Required Fields");
        } else {
            // Returns successful data submission message when the entered information is stored in database.
            $.post("contact-form.php", {
            name1: name,
            email1: email,
            message1: message,
        }, function(data) {
            $("#returnmessage").append(data); // Append returned message to message paragraph.
            if (data == "Your Query has been received, We will contact you soon.") {
            $("#form")[0].reset(); // To reset form fields on success.
        }
        });
        }
    });

    $('.qtyplus').click(function(e){
        // Stop acting like a button
        e.preventDefault();
        // Get the field name
        fieldName = $(this).attr('field');
        // Get its current value
        var currentVal = parseInt($('input[name='+fieldName+']').val());
        // If is not undefined
        if (!isNaN(currentVal)) {
            // Increment only if value is < 20
            if (currentVal < 20)
            {
              $('input[name='+fieldName+']').val(currentVal + 1);
              $('.qtyminus').val("-").removeAttr('style');
                            }
            else
            {
                $('.qtyplus').val("+").css('color','#aaa');
                $('.qtyplus').val("+").css('cursor','not-allowed');
            }
        } else {
            // Otherwise put a 0 there
            $('input[name='+fieldName+']').val(1);

        }
    });
    // This button will decrement the value till 0
    $(".qtyminus").click(function(e) {
        // Stop acting like a button
        e.preventDefault();
        // Get the field name
        fieldName = $(this).attr('field');
        // Get its current value
        var currentVal = parseInt($('input[name='+fieldName+']').val());
        // If it isn't undefined or its greater than 0
        if (!isNaN(currentVal) && currentVal > 1) {
            // Decrement one only if value is > 1
            $('input[name='+fieldName+']').val(currentVal - 1);
            $('.qtyplus').val("+").removeAttr('style');
        } else {
            // Otherwise put a 0 there
            $('input[name='+fieldName+']').val(1);
            $('.qtyminus').val("-").css('color','#aaa');
            $('.qtyminus').val("-").css('cursor','not-allowed');
        }
    });
});
