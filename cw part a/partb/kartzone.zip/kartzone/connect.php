<?php
$connection=mysqli_connect('localhost','root','');//establishing server connection
$db= mysqli_select_db($connection,'kartzone');//selecting database
?>
