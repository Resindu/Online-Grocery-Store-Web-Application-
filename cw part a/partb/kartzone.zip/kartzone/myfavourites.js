
if(document.readyState=='loading'){
  document.addEventListener('DOMContentLoaded',ready)
}else{
  ready()
}

function ready(){
  var removeCartItemButtons = document.getElementsByClassName('btn-remove')
  console.log('removeCartItemButton')

      for (var i = 0; i < removeCartItemButtons.length; i++) {
          var button = removeCartItemButtons[i]
          button.addEventListener('click',removeCartItem)
       }


}



function removeCartItem(event){
                var buttonclicked = event.target
                buttonclicked.parentElement.parentElement.parentElement.parentElement.parentElement.parentElement.remove()
                updateCart()
}
