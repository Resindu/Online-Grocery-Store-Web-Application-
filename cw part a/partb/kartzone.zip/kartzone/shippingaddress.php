<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1"/>

  <script src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
    <link	rel	=	"stylesheet"	href	=	"https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.css"/>
  <script	src	=	"https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.js"></script>
	<link href="https://fonts.googleapis.com/css?family=Open+Sans&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	 <link rel="stylesheet" href="themes/style-theme.min.css" />
	 <link rel="stylesheet" href="css/style.css" />
 <link rel="stylesheet" href="themes/jquery.mobile.icons.min.css" />
 <script src="js/jquery.flexslider.js"></script>
 <script src="js/script.js"></script>
 <script src="js/carousel.js"></script>
  <link	rel	=	"stylesheet"	href	=	"cart.css "/>
	<script src="cart.js">	</script>


  </head>
  <body>

  <div data-role="page"  style=" background: #fff">
		<div data-role="header" data-position="fixed" id="header">
				<div class="ui-grid-c">
						<div class="ui-block-a">
								<a id="retina" href="home.html"><img id="logo" src="images/logo.png"></a>
						</div>
						<div class="ui-block-b">
								<a id="btn-cart" href="cart.html"><img id="cart" src="images/cart.png"></a>
								<p id="cart-count">0</p>
						</div>
						<div class="ui-block-c">
								<div class="dropdown-account">
										<a id="btn-account" class="dropbtn"><img id="account" src="images/acount.png"></a>

								</div>
						</div>
						<div class="ui-block-d">
								<a id="btn-menu" href="#popupPanel" data-rel="popup" data-position-to="window" data-transition="slide" ><img id="menu" src="images/menu.png"></a>
								<div data-role="popup" id="popupPanel" data-corners="false" data-theme="none" data-shadow="false" data-tolerance="0,0">
										<img id="logo" src="images/white LOGO.png">
										<button data-icon="back" data-mini="true">Loyalty Points</button>
	                        <button data-icon="grid" data-mini="true">Promotions</button>
	                        <button data-icon="search" data-mini="true">My Favorites</button>
	                        <button data-icon="user" data-mini="true">Contacts</button>
								</div>
						</div>
				</div>

				<div class="ui-grid-b">
						<div class="ui-block-a">
								<div class="dropdown">
										<a id="btn-categories" class="dropbtn">Categories &#9660;</a>
										<div class="dropdown-content">
												<a href="#">Fruits</a>
												<a href="#">Vegetables</a>
												<a href="#">Grocery</a>
												<a href="#">Beverages</a>
												<a href="#">Grocery Food</a>
										</div>
								</div>
						</div>
						<div class="ui-block-b">
								<input type="search" name="search" id="search" value="" placeholder="Search" />
						</div>
				</div>

		</div>
		      <div data-role="content" >
						<h3 style=" margin: 30px 0">Shipping Addres</h3>
						 <div class="container" style="background:white;  border: 1px solid;border-color:#C4C4C4;  padding: 20px;box-shadow: 2px 2px #C4C4C4 " >
            <form action="shippingaddressDbConnection.php" method="post">
              <div class="address-form" style="font-size:14px">
                 <div data-role="fieldcontain">
									 <label for="email">E-mail</label>
									 <input type="text" name="email"/>
									 <label for="Password">Password</label>
									 <input type="text" name="Password"/>
                    <label for="address1">Address Line 1</label>
                    <input type="text" name="address1"/>
                    <label for="address2">Address Line 2</label>
                    <input type="text" name="address2"/>
                    <label for="city">City</label>
                    <input type="text" name="city">
                    <label for="postalcode">Postal code</label>
                    <input type="text" name="postalcode">

                 </div>
              </div>

							<div class="row">
              <div class="col-xs-4 col-md-6">
              <button class="reset-btn" style="background: none;
               color:#E74614; -webkit-box-shadow: none; -moz-box-shadow: none;
             box-shadow: none;border:none;padding-right:300px">Reset Address</button>
					 </div>
					   </div>
								<div class="row">
                    <div class="col-xs-3"></div>
										<div class="col-xs-3" style="color:#E74614;font-size: 15px;padding-top:15px"><b>cancel</b></div>
                    <div class="col-xs-6">
                      <button type="submit" name="submit" value="confirm" style="font-size: 15px;background:#E74614;color:black;text-shadow:none">confirm </button>
										</div>
								</div>
									</form>
					    </div>

							<div data-role="footer" data-position="inline" id="footer">
									<p id="stayconnected-text"><strong>STAY CONNECTED US WITH VIA:</strong></p>
									<div class="ui-grid-b">
											<div class="ui-block-a">
															<a  id="btn-facebook" href="cart.html"><img class="social-media-icons" id="facebook" src="images/facebook.png"></a>
													</div>
											<div class="ui-block-b">
													<a  id="btn-instagram" href="cart.html"><img class="social-media-icons" id="instagram" src="images/instagram.png"></a>
											</div>
											<div class="ui-block-c">
													<a  id="btn-youtube" href="cart.html"><img class="social-media-icons" id="youtube" src="images/youtube.png"></a>
											</div>
									</div><br>
									<p id="copyright-text">© Copyright 2019 All rights reserved. <br>Contact us via email kartzone@gmail.com</p>
									<br>
							</div>

  </body>
  </html>
