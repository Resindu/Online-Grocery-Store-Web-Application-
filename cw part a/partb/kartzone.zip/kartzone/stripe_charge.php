<?php

$secret_key='sk_test_6OEIaZOZN70Jq4CEAxm3S8b900hdzyTFWh';


// Include configuration file
require_once 'config.php';

$response = array();

// Check whether stripe token is not empty
if(!empty($_POST['stripeToken'])){

    // Get token and buyer info
    $token  = $_POST['stripeToken'];
    $email  = $_POST['stripeEmail'];

    // Include Stripe PHP library
    require_once 'stripe-php/init.php';

    // Set API key
    \Stripe\Stripe::setApiKey(STRIPE_API_KEY);

    // Add customer to stripe
    $customer = \Stripe\Customer::create(array(
        'email' => $email,
        'source'  => $token
    ));

    // Charge a credit or a debit card
    $charge = \Stripe\Charge::create(array(
        'customer' => $customer->id,
        'amount'   => $stripeAmount,
        'currency' => $currency,
        'description' => $productName,
    ));

    // Retrieve charge details
    $chargeJson = $charge->jsonSerialize();

    // Check whether the charge is successful
    if($chargeJson['amount_refunded'] == 0 && empty($chargeJson['failure_code']) && $chargeJson['paid'] == 1 && $chargeJson['captured'] == 1){

        // Order details
        $txnID = $chargeJson['balance_transaction'];
        $paidAmount = ($chargeJson['amount']/100);
        $paidCurrency = $chargeJson['currency'];
        $status = $chargeJson['status'];
        $orderID = $chargeJson['id'];
        $payerName = $chargeJson['source']['name'];

        // Include database connection file
        require_once 'dbConnect.php';

        // Insert tansaction data into the database
        $sql = "INSERT INTO orders(name, email, item_name, item_price, item_price_currency, paid_amount, paid_amount_currency, txn_id, payment_status, created, modified) VALUES('".$payerName."', '".$email."', '".$productName."', '".$productPrice."', '".$currency."', '".$paidAmount."', '".$paidCurrency."', '".$txnID."', '".$status."', NOW(), NOW())";
        $insert = $db->query($sql);
        $last_insert_id = $db->insert_id;

        // If order inserted successfully
        if($last_insert_id && $status == 'succeeded'){
            $response = array(
                'status' => 1,
                'msg' => 'Your Payment has been Successful!',
                'txnData' => $chargeJson
            );
        }else{
            $response = array(
                'status' => 0,
                'msg' => 'Transaction has been failed.'
            );
        }
    }else{
        $response = array(
            'status' => 0,
            'msg' => 'Transaction has been failed.'
        );
    }
}else{
    $response = array(
        'status' => 0,
        'msg' => 'Form submission error...'
    );
}

// Return response
echo json_encode($response);
