<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="payment.css">
  <link rel="stylesheet" href="cart.css">
  <

  <script src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
    <link	rel	=	"stylesheet"	href	=	"https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.css"/>
  <script	src	=	"https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.js"></script>

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

  <title>Payments</title>
</head>
<body>
  <div data-role="page">

  <div data-role="content"  >
  <h3 style=" margin: 40px 0">Payment Information</h3>
  <h5 style=" margin:20px 30px" >Credit/Debit cards</h5>

  <div class="container" style="background:white;  border: 1px solid;border-color:#C4C4C4;  padding: 20px;box-shadow: 2px 2px #C4C4C4; height:auto" >

    <form action="./charge.php" method="post" id="payment-form">

      <div class="form-row">
       <input type="text" name="first_name" class="form-control mb-3 StripeElement StripeElement--empty" placeholder="First Name">
       <input type="text" name="last_name" class="form-control mb-3 StripeElement StripeElement--empty" placeholder="Last Name">
       <input type="email" name="email" class="form-control mb-3 StripeElement StripeElement--empty" placeholder="Email Address">
        <div id="card-element" class="form-control">
          <!-- a Stripe Element will be inserted here. -->
        </div>


        <div class="row" style="margin:30px">
            <div class="col-4 col-xs-3 col-md-2"></div>
            <div class="col-4 col-xs-3 col-md-2" style="color:#E74614;font-size: 15px;padding-top:15px"><b>cancel</b></div>
            <div class="col-4 col-xs-6 col-md-8">
              <button style="font-size: 15px;background:#E74614;color:black;text-shadow:none" data-corners="false">confirm </button>
            </div>
        </div>
        <!-- Used to display form errors -->
        <div id="card-errors" role="alert"></div>
      </div>



    </form>
  </div>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://js.stripe.com/v3/"></script>
  <script src="charge.js"></script>
</div>
</div>
</body>
</html>
