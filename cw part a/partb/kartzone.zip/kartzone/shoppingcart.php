
<?php
include_once('connect.php');
 ?>

 <!DOCTYPE html>
 <html>
 <title>
   display shopping cart
 </title>
 <body>
   <body>

     <?php

     //MySQL Query to read data
     $query = mysqli_query($connection,"select * from products");
     while ($row = mysqli_fetch_array($query)) {
     echo $row['product_id'];

     echo $row['product_name'];



     }
     ?>


 </body>
</html>
