
if(document.readyState=='loading'){
  document.addEventListener('DOMContentLoaded',ready)
}else{
  ready()
}

function ready(){
  var removeCartItemButtons = document.getElementsByClassName('btn-remove')
  console.log('removeCartItemButton')

      for (var i = 0; i < removeCartItemButtons.length; i++) {
          var button = removeCartItemButtons[i]
          button.addEventListener('click',removeCartItem)
       }

    var quantityInput=document.getElementsByClassName('qunatity-input')
    for (var i = 0; i < quantityInput.length; i++) {
        var qinput = quantityInput[i]
        qinput.addEventListener('change',quantityChange)



}

function quantityChange(event){
  qinput=event.target
  if(isNaN(qinput.value)|| qinput.value<=0){
    qinput.value=1
  }
updateCart()
}






function removeCartItem(event){
                var buttonclicked = event.target
                buttonclicked.parentElement.parentElement.parentElement.parentElement.parentElement.remove()
                updateCart()
}

function updateCart(){
          var cartItemsContainer= document.getElementsByClassName('cart-items-container')[0]
           var cartItemRows = document.getElementsByClassName('cart-item')

           var total=0

           for(var i=0;i<cartItemRows.length;i++){
             var itemRow = cartItemRows[i]
             var itemPrice = itemRow.getElementsByClassName('item-price')[0]
             var itemQuantity = itemRow.getElementsByClassName('quantity-input')[0]
             var price=parseFloat(itemPrice.innerText.replace('Rs.',''))
             console.log(price)
             var quantity=itemQuantity.value
             console.log(quantity)
             total=total+price*quantity
             console.log('total is'+total)

             var shipping=document.getElementsByClassName("shipping-amount")[0]
             var shipingamount=parseFloat(shipping.innerText.replace('Rs.',''))
            console.log("shipping"+shipingamount)

             var tax=document.getElementsByClassName('tax-amount')[0]
             var taxamount=parseFloat(tax.innerText.replace('Rs.',''))
               console.log("tax"+taxamount)


           }
            total=Math.round(total*100)/100
            document.getElementsByClassName('subtotal-amount')[0].innerText='Rs.'+total
            document.getElementsByClassName('total-amount')[0].innerText='Rs.'+total


           console.log("total"+total)

}

$('input[type="number"]').niceNumber({

  // auto resize the number input
  autoSize: true,

  // the number of extra character
  autoSizeBuffer: 1,

  // custom button text
  buttonDecrement: '-',
  buttonIncrement: "+",

  // 'around', 'left', or 'right'
  buttonPosition: 'around'

});

$(function(){

  $('input[type="number"]').niceNumber();

});

});
