<?php
$connection=mysqli_connect('localhost','root','');//establishing server connection
if(!$connection){
  echo('not connectedd to server');
}

if(!mysqli_select_db($connection,'kartzone')){
  echo('database is not connected');
}

$email=$_POST['email'];
$password=$_POST['password'];
 $address1=$_POST['address1'];
 $address2=$_POST['address2'];
 $city=$_POST['city'];
 $postalcode=$_POST['postalcode'];

$sql="INSERT INTO shippingaddress(email,password,address1,address2,city,postalcode) VALUES('$email','$password','$address1','$address2','$city','$postalcode')";

if(!mysqli_query($connection,$sql)){
  echo'data not inserted';
}else{
  echo 'inserted';
}


 ?>
