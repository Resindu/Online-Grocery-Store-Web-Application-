<?php
  if(!empty($_GET['tid'] && !empty($_GET['product']))) {
    $GET = filter_var_array($_GET, FILTER_SANITIZE_STRING);

    $tid = $GET['tid'];
    $product = $GET['product'];
  } else {
    header('Location: payment.php');
  }
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <script src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
    <link	rel	=	"stylesheet"	href	=	"https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.css"/>
  <script	src	=	"https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.js"></script>

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

  <title>Thank You</title>
</head>
<body>

  <div data-role="page">

		      <div data-role="content" style="margin:100px 0" >
             <div class="container" style="background:white;  border: 1px solid;border-color:#C4C4C4;  padding: 20px;box-shadow: 2px 2px #C4C4C4; height:auto">
               <div class="row" style="background:yellow;max-width:auto">
                 <div class="col-xs-3">
                   <div class="successmsg-img" style="margin:40px 0">
                       <img src="C:\xampp\htdocs\kartzone\cw images\tick-green.png">
                   </div>


                </div>
                <div class="col-xs-9">
                 <h4 style="margin:60px 0;padding-left:1px"><b>Payment Successful</b></h4>
                 <h4>Thank you for purchasing <?php echo $product; ?></h2>
                 <hr>
                 <p>Your transaction ID is <?php echo $tid; ?></p>
                 <p>Check your email for more info</p>
                </div>
               </div>
              <div class="row">
                  <div class="col-xs-12" style="width:auto;left:16%;margin:40px 0">
                    <button style="font-size: 15px;background:#E74614;color:black;text-shadow:none;padding:10px 30px 10px 30px" data-corners="false" >Continue Shopping </button>

                  </div>
              </div>

             </div>
          </div>

</div>



</body>
</html>
